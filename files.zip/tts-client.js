// tts-client.js - index.html mein <script src="/tts-client.js" defer></script> se jodo.
// CSP ki wajah se inline <script> kaam nahi karega, isliye JS alag file mein rakho.
//
// HTML mein yeh ids chahiye (apne ids ke hisaab se neeche badal lo):
//   <textarea id="text"></textarea>
//   <span id="counter">0/500</span>
//   <button id="generate">Generate Voice</button>
//   <p id="error" role="alert"></p>
//   <audio id="player" controls hidden></audio>
// Voice aur tone ke liye: <select id="voice"> aur <select id="tone">
// (option values api/tts.js ke VOICES / TONES ke keys se match hone chahiye)

(() => {
  const MAX = 500;
  const $ = (id) => document.getElementById(id);
  const textEl = $("text");
  const counter = $("counter");
  const btn = $("generate");
  const errEl = $("error");
  const player = $("player");
  let lastUrl = null;

  function updateCounter() {
    const n = textEl.value.length;
    counter.textContent = `${n}/${MAX}`;
    counter.style.color = n > MAX ? "#dc2626" : n > MAX * 0.9 ? "#d97706" : "#4b5563";
    btn.disabled = n === 0 || n > MAX;
  }
  textEl.addEventListener("input", updateCounter);
  updateCounter();

  btn.addEventListener("click", async () => {
    errEl.textContent = "";
    const label = btn.textContent;
    btn.disabled = true;
    btn.textContent = "Generating...";
    try {
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: textEl.value,
          voice: $("voice").value,
          tone: $("tone").value,
        }),
      });
      if (!res.ok) {
        let msg = "Something went wrong. Please try again.";
        try { msg = (await res.json()).error || msg; } catch (e) {}
        throw new Error(msg);
      }
      const blob = await res.blob();
      if (lastUrl) URL.revokeObjectURL(lastUrl);
      lastUrl = URL.createObjectURL(blob);
      player.src = lastUrl;
      player.hidden = false;
      player.play().catch(() => {});
    } catch (e) {
      errEl.textContent = e.message;
    } finally {
      btn.textContent = label;
      updateCounter();
    }
  });
})();
