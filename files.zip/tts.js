// api/tts.js - Vercel serverless function (plain HTML projects ke liye)
// Flow: method check -> origin check -> validate -> IP limit -> daily cap -> Gemini -> WAV

const crypto = require("crypto");

// ====== SETTINGS (yahan badlo) ======
const MAX_CHARS = 500;          // server-side hard limit
const IP_LIMIT_PER_HOUR = 8;    // ek IP se per hour kitni generations
const DAILY_GLOBAL_CAP = 100;   // total per day. Isse apne Gemini free-tier limit se KAM rakho
const MODEL = process.env.GEMINI_TTS_MODEL || "gemini-2.5-flash-preview-tts";

// UI ke naam -> Gemini voice. Apne UI ke hisaab se edit karo.
const VOICES = {
  Emma: "Kore",
  James: "Charon",
  Alex: "Puck",
  Sophia: "Zephyr",
  Ryan: "Fenrir",
  Lily: "Aoede",
};

// Tone allowlist. User ka text seedha instruction mein nahi jaata.
const TONES = {
  Professional: "Say in a clear, professional tone",
  Friendly: "Say in a warm, friendly and cheerful tone",
  Calm: "Say in a calm, soothing tone",
  Energetic: "Say in a fast, energetic tone",
};
// ====================================

function fail(res, status, message) {
  return res.status(status).json({ error: message });
}

async function redis(commands) {
  const url = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;
  if (!url || !token) throw new Error("redis_not_configured");
  const r = await fetch(url + "/pipeline", {
    method: "POST",
    headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" },
    body: JSON.stringify(commands),
  });
  if (!r.ok) throw new Error("redis_error");
  return r.json(); // [{result: ...}, ...]
}

function pcmToWav(pcm, sampleRate = 24000) {
  const h = Buffer.alloc(44);
  h.write("RIFF", 0);
  h.writeUInt32LE(36 + pcm.length, 4);
  h.write("WAVE", 8);
  h.write("fmt ", 12);
  h.writeUInt32LE(16, 16);
  h.writeUInt16LE(1, 20); // PCM
  h.writeUInt16LE(1, 22); // mono
  h.writeUInt32LE(sampleRate, 24);
  h.writeUInt32LE(sampleRate * 2, 28);
  h.writeUInt16LE(2, 32);
  h.writeUInt16LE(16, 34);
  h.write("data", 36);
  h.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([h, pcm]);
}

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");

  // 1. Sirf POST
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return fail(res, 405, "Method not allowed");
  }

  // 2. Doosri websites se calls roko (basic check)
  const origin = req.headers.origin;
  if (origin) {
    let originHost = "";
    try { originHost = new URL(origin).host; } catch (e) {}
    if (originHost !== req.headers.host) return fail(res, 403, "Forbidden");
  }

  // 3. Body validate
  let body = req.body;
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch (e) { body = null; }
  }
  if (!body || typeof body !== "object") return fail(res, 400, "Invalid request");

  const text = typeof body.text === "string" ? body.text.trim() : "";
  if (!text) return fail(res, 400, "Please enter some text.");
  if (text.length > MAX_CHARS) {
    return fail(res, 400, `Text is too long. Maximum ${MAX_CHARS} characters.`);
  }

  const voiceName = VOICES[body.voice];
  if (!voiceName) return fail(res, 400, "Invalid voice.");
  const tonePrefix = TONES[body.tone] || TONES.Professional;

  if (!process.env.GEMINI_API_KEY) {
    console.error("GEMINI_API_KEY missing");
    return fail(res, 503, "Service is not available right now.");
  }

  // 4. Rate limits (fail closed: Redis na ho to request band)
  try {
    const rawIp =
      (req.headers["x-vercel-forwarded-for"] || req.headers["x-forwarded-for"] || "unknown")
        .toString()
        .split(",")[0]
        .trim();
    // IP hash karke store karte hain, asli IP nahi
    const ipHash = crypto.createHash("sha256").update(rawIp).digest("hex").slice(0, 24);
    const hour = Math.floor(Date.now() / 3600000);
    const ipKey = `rl:${ipHash}:${hour}`;

    const ipRes = await redis([["INCR", ipKey], ["EXPIRE", ipKey, 3600]]);
    if (ipRes[0].result > IP_LIMIT_PER_HOUR) {
      return fail(res, 429, "Hourly limit reached. Please try again later.");
    }

    const dayKey = `cap:${new Date().toISOString().slice(0, 10)}`;
    const dayRes = await redis([["INCR", dayKey], ["EXPIRE", dayKey, 90000]]);
    if (dayRes[0].result > DAILY_GLOBAL_CAP) {
      return fail(res, 429, "Daily limit reached for today. Please come back tomorrow.");
    }
  } catch (err) {
    console.error("Rate limit error:", err.message);
    return fail(res, 503, "Service is not available right now.");
  }

  // 5. Gemini call
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 25000);
  try {
    const r = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
      {
        method: "POST",
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": process.env.GEMINI_API_KEY,
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `${tonePrefix}: ${text}` }] }],
          generationConfig: {
            responseModalities: ["AUDIO"],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName } } },
          },
        }),
      }
    );

    if (r.status === 429) {
      return fail(res, 429, "Too much traffic right now. Please try again in a few minutes.");
    }
    if (!r.ok) {
      console.error("Gemini error:", r.status, (await r.text()).slice(0, 500));
      return fail(res, 502, "Something went wrong. Please try again.");
    }

    const data = await r.json();
    const b64 = data?.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!b64) {
      console.error("No audio in response");
      return fail(res, 502, "Something went wrong. Please try again.");
    }

    const wav = pcmToWav(Buffer.from(b64, "base64"));
    res.setHeader("Content-Type", "audio/wav");
    return res.status(200).send(wav);
  } catch (err) {
    console.error("TTS error:", err.name, err.message);
    return fail(res, 502, "Something went wrong. Please try again.");
  } finally {
    clearTimeout(timer);
  }
};
